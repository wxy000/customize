function getConfig(){
    let result;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://xxx/plugin-custom/wxy/config/config.json', false);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            let data = JSON.parse(xhr.responseText);
            // 在此处处理数据
            result = data;
        }
    };
    xhr.onerror = function() {
        console.error('读取JSON文件时发生错误');
    };
    xhr.send();
    return result;
}
let wxyConfig = getConfig();

/*function wxyMain(){
    let nowtime = Date.now();
    let li = document.createElement("li");
    li.innerHTML = '<i data-v-'+nowtime+' class="iconfont icon-user"></i>wxy主题美化';
    li.setAttribute("id","wxyTitleBeauty");
    li.setAttribute("class","el-dropdown-menu__item");
    li.setAttribute("tabindex","-1");
    li.setAttribute("role","menuitem");
    li.setAttribute("data-el-collection-item","");
    li.setAttribute("aria-disabled","false");
    li.onclick = function(){
        window.open(wxyConfig.url+"/plugin-custom/wxy/html/wxy.html","_blank","resizable,scrollbars,status");
    };
    let s = document.getElementsByClassName("el-dropdown-menu")[0].firstElementChild;
    s.parentNode.insertBefore(li,s);
}
//延迟1秒加载
(function(){
    setTimeout(function(){
        wxyMain();
    }, 1000)
})();*/

//创建字体css样式
function wxyCreateFont(){
    let styleStr = "";
    for (var i=0; i<wxyConfig.wxyFontFamilys.length; i++){
        styleStr += '@font-face{font-family: "'+wxyConfig.wxyFontFamilys[i].name+'";src: url("'+wxyConfig.url+'/plugin-custom/wxy/font/'+wxyConfig.wxyFontFamilys[i].path+'");}';
    }
    let style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = styleStr;
    document.getElementsByTagName('head').item(0).appendChild(style);
}
wxyCreateFont();

function wxyCreateScript(src){
    let script = document.createElement("script");
    script.src = src;
    // 保证js按顺序执行
    script.async = false;
    let s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(script,s);
}

wxyCreateScript(wxyConfig.url+"/plugin-custom/wxy/js/lunar.js");
wxyCreateScript(wxyConfig.url+"/plugin-custom/wxy/js/customize.js");